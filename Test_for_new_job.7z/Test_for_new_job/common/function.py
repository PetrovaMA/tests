from argparse import Action
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

#поиск ID
def findID(driver, whatID, timeout = 10):
    wait = WebDriverWait(driver, timeout).until(
        EC.element_to_be_clickable((By.ID, whatID)))
    if (wait == False):
        print("error")
    else:
        element = driver.find_element(By.ID, whatID)
    return element

#поиск по XPATH
def findXPATH(driver, whatXPATH, timeout = 10):
    wait = WebDriverWait(driver, timeout).until(
        EC.element_to_be_clickable((By.XPATH, whatXPATH)))
    if (wait == False):
        print("error")
    else:
        element = driver.find_element(By.XPATH, whatXPATH)
        return element

#поиск по CSS Селектору
def findCssSelector(driver, whatCssSelector, timeout = 10):
    wait = WebDriverWait(driver, timeout).until(
        EC.element_to_be_clickable((By.CSS_SELECTOR, whatCssSelector)))
    if (wait == False):
        print("error")
    else:
        element = driver.find_element(By.CSS_SELECTOR, whatCssSelector)
        return element