from argparse import Action
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.by import By
import time
import keyboard
import random
import string
import sys


sys.path.insert(0, '../')

from common.function import(
    findID,
    findXPATH,
    findCssSelector,
)

user = "manager@mail.ru"
passw = "1"
random_string = ''.join(random.choices(string.ascii_letters + string.digits, k=4))

def runTest(user, passw, random_string):
    driver = webdriver.Firefox()
    driver.maximize_window()
    actions = ActionChains(driver)

    #Заходим на сайт
    driver.get('http://users.bugred.ru')

    #кнопка вход
    elementCssSelector = findCssSelector(driver, "li.newlink:nth-child(2) > a:nth-child(1) > span:nth-child(1)")
    elementCssSelector.click()
    time.sleep(3)

    #авторизуемся manager@mail.ru
    #заполняем поле логина
    elementCssSelector = findCssSelector(driver, "div.col-md-6:nth-child(1) > form:nth-child(3) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(1) > td:nth-child(2) > input:nth-child(1)")
    elementCssSelector.clear()
    elementCssSelector.send_keys(user)

    #заполняем поле пороля
    elementCssSelector = findCssSelector(driver, "div.col-md-6:nth-child(1) > form:nth-child(3) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(2) > td:nth-child(2) > input:nth-child(1)")
    elementCssSelector.clear()
    elementCssSelector.send_keys(passw)
    time.sleep(1)

    #Нажать кнопку авторизации
    elementCssSelector = findCssSelector(driver, "div.col-md-6:nth-child(1) > form:nth-child(3) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(2) > td:nth-child(1)")
    elementCssSelector.click()
    elementCssSelector = findCssSelector(driver, "div.col-md-6:nth-child(1) > form:nth-child(3) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(3) > td:nth-child(2) > input:nth-child(1)")
    elementCssSelector.click()
    time.sleep(2)

    #Регистрация рандомной почты
    elementCssSelector = findCssSelector(driver, ".btn-danger")
    elementCssSelector.click()

    email = f'{random_string}@mail.ru'

    #заполняем форму "Добавить пользователя"
    #рандомный юзер
    elementCssSelector = findCssSelector(driver, ".field_name > input:nth-child(1)")
    elementCssSelector.click()
    elementCssSelector.send_keys(random_string)
    time.sleep(0.5)

    #рандомная почта
    elementCssSelector = findCssSelector(driver, ".field_email > input:nth-child(1)")
    elementCssSelector.click()
    elementCssSelector.send_keys(email)
    search_email = email
    time.sleep(0.5)

    #пароль
    elementCssSelector = findCssSelector(driver, "input.overflow")
    elementCssSelector.click()
    elementCssSelector.send_keys("1")

    #дата
    elementCssSelector = findCssSelector(driver, ".field_birthday > input:nth-child(1)")
    elementCssSelector.click()
    elementCssSelector.send_keys("01021990")
    elementCssSelector.send_keys(Keys.ENTER)

    #пол
    elementCssSelector = findCssSelector(driver, "select.form-control")
    elementCssSelector.click()
    elementCssSelector = findCssSelector(driver, "select.form-control > option:nth-child(2)")
    elementCssSelector.click()

    #начал работать в компании
    elementCssSelector = findCssSelector(driver, ".field_date_start > input:nth-child(1)")
    elementCssSelector.click()
    elementCssSelector.send_keys("01012023")
    elementCssSelector.send_keys(Keys.ENTER)

    #Увлечения
    elementCssSelector = findCssSelector(driver, "textarea.form-control")
    elementCssSelector.click()
    elementCssSelector. send_keys("test 111111113123")

    #имя1
    elementCssSelector = findCssSelector(driver, ".field_name1 > input:nth-child(1)")
    elementCssSelector.click()
    elementCssSelector.send_keys(random_string)

    #фамилия1
    elementCssSelector = findCssSelector(driver, ".field_surname1 > input:nth-child(1)")
    elementCssSelector.click()
    elementCssSelector.send_keys(random_string)

    #отчество1
    elementCssSelector = findCssSelector(driver, ".numberfilter")
    elementCssSelector.click()
    elementCssSelector.send_keys(random_string)

    #кошечка

    elementCssSelector = findCssSelector(driver, ".numberfilter2")
    elementCssSelector.click()
    elementCssSelector.send_keys("кот")

    #собачка

    elementCssSelector = findCssSelector(driver, ".field_dog > input:nth-child(1)")
    elementCssSelector.click()
    elementCssSelector.send_keys("дог")

    #попугайчик

    elementCssSelector = findCssSelector(driver, ".checkjs")
    elementCssSelector.click()
    elementCssSelector.send_keys("Гоша")

    #Морская свинка

    elementCssSelector = findCssSelector(driver, ".field_cavy > input:nth-child(1)")
    elementCssSelector.click()
    elementCssSelector.send_keys("ми")

    #хомячок

    elementCssSelector = findCssSelector(driver, ".field_hamster > input:nth-child(1)")
    elementCssSelector.click()
    elementCssSelector.send_keys("хом")

    #белочка
    elementCssSelector = findCssSelector(driver, ".field_squirrel > input:nth-child(1)")
    elementCssSelector.click()
    elementCssSelector.send_keys("бел")

    #телефон
    elementCssSelector = findCssSelector(driver, ".numberfilter3")
    elementCssSelector.click()
    elementCssSelector.send_keys("1234567")

    #адрес
    elementCssSelector = findCssSelector(driver, ".field_adres > input:nth-child(1)")
    elementCssSelector.click()
    elementCssSelector.send_keys("ул. Лубянка")

    #ИНН
    elementCssSelector = findCssSelector(driver, ".field_inn > input:nth-child(1)")
    elementCssSelector.clear()
    elementCssSelector.send_keys("1234567890")


    #добавить пользователя
    elementCssSelector = findCssSelector(driver, ".btn")
    elementCssSelector.click()
    time.sleep(1)

    #делаем логаут для manager@mail.ru
    elementCssSelector = findCssSelector(driver, ".dropdown-toggle")
    elementCssSelector.click()
    time.sleep(1)
    elementCssSelector = findCssSelector(driver, ".dropdown-menu > li:nth-child(3)")
    elementCssSelector.click()
    time.sleep(2)

    #входим новым пользователем
    #кнопка вход
    elementCssSelector = findCssSelector(driver, "li.newlink:nth-child(2) > a:nth-child(1) > span:nth-child(1)")
    elementCssSelector.click()
    time.sleep(3)

    elementCssSelector = findCssSelector(driver, "div.col-md-6:nth-child(1) > form:nth-child(3) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(1) > td:nth-child(2) > input:nth-child(1)")
    elementCssSelector.clear()
    elementCssSelector.send_keys(search_email)

    #заполняем поле пороля
    elementCssSelector = findCssSelector(driver, "div.col-md-6:nth-child(1) > form:nth-child(3) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(2) > td:nth-child(2) > input:nth-child(1)")
    elementCssSelector.clear()
    elementCssSelector.send_keys("1")
    time.sleep(1)

    #Нажать кнопку авторизации
    elementCssSelector = findCssSelector(driver, "div.col-md-6:nth-child(1) > form:nth-child(3) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(2) > td:nth-child(1)")
    elementCssSelector.click()
    elementCssSelector = findCssSelector(driver, "div.col-md-6:nth-child(1) > form:nth-child(3) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(3) > td:nth-child(2) > input:nth-child(1)")
    elementCssSelector.click()
    time.sleep(2)

    #поиск по названию почты
    elementCssSelector = findCssSelector(driver, "table.table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(4) > td:nth-child(1) > input:nth-child(1)")
    elementCssSelector.click()
    elementCssSelector.send_keys(search_email)
    
    elementCssSelector = findCssSelector(driver, "button.btn")
    elementCssSelector.click()
    time.sleep(1)

    #посмотреть
    elementCssSelector = findCssSelector(driver, ".ajax_load_row > tr:nth-child(1) > td:nth-child(7) > a:nth-child(1)")
    elementCssSelector.click()
    
    #делаем логаут для нового пользователя
    elementCssSelector = findCssSelector(driver, ".dropdown-toggle")
    elementCssSelector.click()
    time.sleep(1)
    elementCssSelector = findCssSelector(driver, ".dropdown-menu > li:nth-child(3)")
    elementCssSelector.click()
    time.sleep(2)

    #кнопка вход
    elementCssSelector = findCssSelector(driver, "li.newlink:nth-child(2) > a:nth-child(1) > span:nth-child(1)")
    elementCssSelector.click()
    time.sleep(3)


    #авторизуемся manager@mail.ru
    #заполняем поле логина
    elementCssSelector = findCssSelector(driver, "div.col-md-6:nth-child(1) > form:nth-child(3) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(1) > td:nth-child(2) > input:nth-child(1)")
    elementCssSelector.clear()
    elementCssSelector.send_keys(user)

    #заполняем поле пороля
    elementCssSelector = findCssSelector(driver, "div.col-md-6:nth-child(1) > form:nth-child(3) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(2) > td:nth-child(2) > input:nth-child(1)")
    elementCssSelector.clear()
    elementCssSelector.send_keys(passw)
    time.sleep(1)

    #Нажать кнопку авторизации
    elementCssSelector = findCssSelector(driver, "div.col-md-6:nth-child(1) > form:nth-child(3) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(2) > td:nth-child(1)")
    elementCssSelector.click()
    elementCssSelector = findCssSelector(driver, "div.col-md-6:nth-child(1) > form:nth-child(3) > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(3) > td:nth-child(2) > input:nth-child(1)")
    elementCssSelector.click()
    time.sleep(2)

    #Снова ищем пользователя 
    #поиск по названию почты
    elementCssSelector = findCssSelector(driver, "table.table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(4) > td:nth-child(1) > input:nth-child(1)")
    elementCssSelector.click()
    elementCssSelector.send_keys(search_email)
    
    elementCssSelector = findCssSelector(driver, "button.btn")
    elementCssSelector.click()
    time.sleep(1)

    #удаляем
    elementCssSelector = findCssSelector(driver, ".ajax_load_row > tr:nth-child(1) > td:nth-child(6) > a:nth-child(1)")
    elementCssSelector.click()
    time.sleep(2)

    return driver

try:
    driver = runTest(user, passw, random_string)
    print("Yes!")
except:
    print("Error!")
finally:
    driver.quit()